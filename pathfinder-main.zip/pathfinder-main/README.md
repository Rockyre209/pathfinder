Find the shortest distance between two points using Dijkstra algorithm
this app makes use of the Dijkstra algorithm and lets the user draw any mazes between the points to make the pathfinding process harder
app will visualize the pathfinding process so it is easy to keep up
